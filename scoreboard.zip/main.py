"""Entry point: logging, settings, Tk root, scoreboard app."""

from __future__ import annotations

import logging
import sys
import tkinter as tk

from scoreboard.config.settings import load_settings
from scoreboard.logging_config import configure_logging
from scoreboard.app import ScoreboardApp


def main() -> None:
    configure_logging(logging.INFO)
    log = logging.getLogger("scoreboard.main")
    try:
        settings = load_settings()
    except Exception:
        log.exception("Failed to load settings; exiting")
        sys.exit(1)

    root = tk.Tk()
    try:
        ScoreboardApp(root, settings=settings)
    except Exception:
        log.exception("Failed to start scoreboard UI")
        root.destroy()
        sys.exit(1)

    root.mainloop()


if __name__ == "__main__":
    main()
