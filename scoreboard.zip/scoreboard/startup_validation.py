"""Startup checks: log asset paths, mpv, slideshow, state, hotkeys."""

from __future__ import annotations

import logging
import os
import shutil
from pathlib import Path

from scoreboard.config.settings import Settings, summarize_settings
from scoreboard.hotkeys import parse_recording_hotkey_to_tk_bind

_LOG = logging.getLogger(__name__)


def _mpv_candidates(settings: Settings) -> list[str]:
    candidates: list[str] = []
    if settings.mpv_path:
        candidates.append(settings.mpv_path)
    discovered = shutil.which("mpv")
    if discovered:
        candidates.append(discovered)
    discovered_exe = shutil.which("mpv.exe")
    if discovered_exe:
        candidates.append(discovered_exe)
    candidates.extend(
        [
            r"C:\Program Files\mpv\mpv.exe",
            r"C:\Program Files (x86)\mpv\mpv.exe",
            r"C:\mpv\mpv.exe",
        ]
    )
    out: list[str] = []
    seen: set[str] = set()
    for c in candidates:
        if c and c not in seen:
            seen.add(c)
            out.append(c)
    return out


def resolve_mpv_executable(settings: Settings) -> str | None:
    """Same resolution order as ReplayController (for validation logging)."""
    for candidate in _mpv_candidates(settings):
        if os.path.isfile(candidate):
            return candidate
    return None


def log_startup_validation(settings: Settings, state_path: Path) -> None:
    """Validate paths and configuration; log clearly without crashing."""
    _LOG.info("Startup configuration summary:\n%s", summarize_settings(settings))

    bg = Path(settings.scoreboard_background_image)
    if bg.is_file():
        _LOG.info("Scoreboard background OK: %s", bg.resolve())
    else:
        _LOG.error("Scoreboard background missing: %s", bg.resolve())

    slate = Path(settings.replay_slate_image)
    if slate.is_file():
        _LOG.info("Replay slate image OK: %s", slate.resolve())
    else:
        _LOG.error("Replay slate image missing: %s", slate.resolve())

    sd = Path(settings.slideshow_dir)
    if sd.is_dir():
        _LOG.info("Slideshow directory OK: %s", sd.resolve())
    else:
        _LOG.warning("Slideshow directory not found or not a directory: %s", sd.resolve())

    rv = Path(settings.replay_video_path)
    if rv.is_file():
        _LOG.info("Replay video file OK: %s", rv.resolve())
    else:
        _LOG.warning("Replay video path missing or not a file: %s", rv.resolve())

    mpv = resolve_mpv_executable(settings)
    if mpv:
        _LOG.info("mpv executable resolved: %s", mpv)
    else:
        _LOG.warning("mpv executable not found (replay video will not start)")

    if state_path.is_file():
        try:
            state_path.read_text(encoding="utf-8")
            _LOG.info("State file readable: %s", state_path.resolve())
        except OSError:
            _LOG.exception("State file not readable: %s", state_path.resolve())
    else:
        _LOG.info("State file does not exist yet: %s", state_path.resolve())

    for name, spec, default in (
        ("RECORDING_START_HOTKEY", settings.recording_start_hotkey, "Ctrl+Shift+g"),
        ("RECORDING_DISMISS_HOTKEY", settings.recording_dismiss_hotkey, "Ctrl+Alt+m"),
        ("BLACK_SCREEN_HOTKEY", settings.black_screen_hotkey, "Ctrl+Shift+b"),
    ):
        p = parse_recording_hotkey_to_tk_bind(spec)
        if p is None:
            _LOG.warning(
                "%s=%r invalid; UI will fall back toward %r when binding",
                name,
                spec,
                default,
            )
        else:
            _LOG.info("%s=%r -> %s", name, spec, p)

    _LOG.info(
        "Timing: idle_timeout_ms=%s recording_duration_sec=%s ended_hold_ms=%s",
        settings.idle_timeout_ms,
        settings.recording_duration_sec,
        settings.recording_ended_hold_ms,
    )
