"""Centralized Tk ``after`` scheduling with safe cancel and optional grouping."""

from __future__ import annotations

import logging
import tkinter as tk
from collections.abc import Callable
from typing import Any

_LOG = logging.getLogger(__name__)


class AfterScheduler:
    """Tracks scheduled callbacks so shutdown and teardown can cancel reliably."""

    def __init__(self, root: tk.Misc, logger: logging.Logger | None = None) -> None:
        self._root = root
        self._log = logger or _LOG
        self._jobs: set[str] = set()

    def schedule(self, delay_ms: int, callback: Callable[[], Any]) -> str | None:
        """Schedule callback; exceptions in callback are logged. Returns job id or None."""

        def wrapper() -> None:
            self._jobs.discard(jid)
            try:
                callback()
            except tk.TclError:
                self._log.debug("after callback TclError (widget destroyed?)", exc_info=True)
            except Exception:
                self._log.exception("after callback failed")

        jid = self._root.after(delay_ms, wrapper)
        self._jobs.add(jid)
        return jid

    def cancel(self, job_id: str | None) -> None:
        if job_id is None:
            return
        try:
            self._root.after_cancel(job_id)
        except (ValueError, tk.TclError) as e:
            self._log.debug("after_cancel ignored: %s", e)
        self._jobs.discard(job_id)

    def cancel_all_tracked(self) -> None:
        for jid in list(self._jobs):
            self.cancel(jid)


class JobGroup:
    """Bundle several after() ids for feature teardown (e.g. screensaver fade + interval)."""

    def __init__(self, scheduler: AfterScheduler) -> None:
        self._scheduler = scheduler
        self._ids: list[str | None] = []

    def schedule(self, delay_ms: int, callback: Callable[[], Any]) -> str | None:
        jid = self._scheduler.schedule(delay_ms, callback)
        self._ids.append(jid)
        return jid

    def cancel_all(self) -> None:
        for jid in self._ids:
            self._scheduler.cancel(jid)
        self._ids.clear()
